export default {
    Query: {
        holaMundo: (parent, args, context, info) => "Hola Mundo!!!"
    }
}