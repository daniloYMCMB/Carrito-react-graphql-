# Riqra challenge con node, graphql, react, mysql

## 01 - Configuración GraphQL y Node